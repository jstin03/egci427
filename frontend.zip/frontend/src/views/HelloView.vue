<template>
       
    <sui-header as="h1" textAlign="center">Welcome,</sui-header>
    <sui-header as="h2" textAlign="center">
        this is an application for contact management <br />
        your can create, update, delete and search for your contact <RouterLink to="/contacts">here</RouterLink>
    </sui-header>

</template>