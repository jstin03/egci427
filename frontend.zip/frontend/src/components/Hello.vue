<template>
    
    <sui-header as="h1" textAlign="center">Welcome...</sui-header>
    <sui-header as="h2" textAlign="center">this is an application for contact management</sui-header>

</template>